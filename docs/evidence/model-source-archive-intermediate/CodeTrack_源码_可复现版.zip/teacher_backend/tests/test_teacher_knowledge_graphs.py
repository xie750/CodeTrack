from io import BytesIO

from fastapi.testclient import TestClient
import pytest
from docx import Document
from pypdf import PdfWriter
from pptx import Presentation

from teacher_backend.app.main import app
from teacher_backend.app.database import SessionLocal
from teacher_backend.app.models import TeacherGraphNodeAttachment
from teacher_backend.app.teacher_graphs import open_unified_session
from backend.app.models import StudentKnowledgeGraph


@pytest.fixture
def client():
    with TestClient(app) as test_client:
        yield test_client


def test_teacher_knowledge_graph_crud_and_persistence(client):
    created = client.post(
        "/api/teacher/knowledge-graphs",
        json={"title": "算法课程图谱", "description": "课程关系草稿", "target_classes": ["软件 1 班"]},
    )
    assert created.status_code == 201
    graph = created.json()["data"]
    assert graph["status"] == "draft"
    assert graph["nodes"][0]["label"] == "核心知识点"
    graph_id = graph["id"]

    extra_node = {
        "id": "node-custom-test",
        "label": "排序算法",
        "type": "方法",
        "description": "比较常见排序策略",
        "difficulty": 3,
        "x": 650,
        "y": 270,
        "color": "#0f766e",
        "source": "custom",
    }
    nodes = graph["nodes"] + [extra_node]
    edge = {
        "id": "edge-custom-test",
        "source": graph["nodes"][0]["id"],
        "target": extra_node["id"],
        "type": "前驱",
        "label": "前驱",
    }
    saved = client.put(
        f"/api/teacher/knowledge-graphs/{graph_id}",
        json={
            "title": "算法课程图谱",
            "description": "已编辑",
            "target_classes": ["软件 1 班", "软件 2 班"],
            "status": "draft",
            "nodes": nodes,
            "edges": [edge],
        },
    )
    assert saved.status_code == 200
    assert saved.json()["data"]["edges"] == [edge]

    rejected_publish = client.post(f"/api/teacher/knowledge-graphs/{graph_id}/publish", json={"class_ids": []})
    assert rejected_publish.status_code == 422
    closed_class_publish = client.post(f"/api/teacher/knowledge-graphs/{graph_id}/publish", json={"class_ids": ["class-ds1"]})
    assert closed_class_publish.status_code == 422

    published = client.post(f"/api/teacher/knowledge-graphs/{graph_id}/publish", json={"class_ids": ["class-se1"]})
    assert published.status_code == 200
    published_data = published.json()["data"]
    assert published_data["status"] == "published"
    assert published_data["target_class_ids"] == ["class-se1"]
    assert published_data["synced_student_graphs"][0]["student_graph_id"] == "kg_ta_se1_ds_001"

    unified_db, _ = open_unified_session()
    try:
        student_graph = unified_db.get(StudentKnowledgeGraph, "kg_ta_se1_ds_001")
        assert student_graph is not None
        assert student_graph.title == "算法课程图谱"
        assert student_graph.class_id == "class_se_001"
        other_class_graph = unified_db.get(StudentKnowledgeGraph, "kg_ta_cs1_ds_001")
        assert other_class_graph is not None
        assert other_class_graph.title != "算法课程图谱"
    finally:
        unified_db.close()

    listing = client.get("/api/teacher/knowledge-graphs")
    assert listing.status_code == 200
    row = next(item for item in listing.json()["data"] if item["id"] == graph_id)
    assert row["node_count"] == 2
    assert row["edge_count"] == 1
    assert "nodes" not in row

    restored = client.get(f"/api/teacher/knowledge-graphs/{graph_id}").json()["data"]
    assert restored["nodes"][1]["x"] == 650
    assert restored["edges"][0]["id"] == "edge-custom-test"

    deleted = client.delete(f"/api/teacher/knowledge-graphs/{graph_id}")
    assert deleted.status_code == 200
    assert client.get(f"/api/teacher/knowledge-graphs/{graph_id}").status_code == 404


def test_teacher_knowledge_graph_from_text_files_uses_fallback(client):
    response = client.post(
        "/api/teacher/knowledge-graphs/from-files",
        data={
            "title": "数据结构资料图谱",
            "description": "从讲义生成",
            "target_classes": "Python A 班，Python B 班\n实验班",
        },
        files=[
            ("files", ("outline.md", BytesIO("# 线性表\n## 栈与队列\n排序算法\n图的遍历\n递归方法".encode()), "text/markdown")),
            ("files", ("notes.txt", BytesIO("查找方法\n算法复杂度\n综合项目实践".encode()), "text/plain")),
        ],
    )
    assert response.status_code == 201
    graph = response.json()["data"]
    assert graph["status"] == "draft"
    assert graph["target_classes"] == ["Python A 班", "Python B 班", "实验班"]
    assert len(graph["source_files"]) == 2
    assert graph["source_files"][0]["parser"] == "markdown"
    assert graph["source_files"][0]["chunking_strategy"]
    assert graph["source_files"][0]["child_chunk_count"] >= 1
    assert 6 <= graph["node_count"] <= 14
    assert graph["edge_count"] == graph["node_count"] - 1
    assert "父切片" in graph["source_summary"]


def test_teacher_knowledge_graph_validation_and_permissions(client):
    unsupported = client.post(
        "/api/teacher/knowledge-graphs/from-files",
        data={"title": "错误格式"},
        files={"files": ("archive.zip", b"not-a-document", "application/zip")},
    )
    assert unsupported.status_code == 415

    denied = client.get("/api/teacher/knowledge-graphs", headers={"X-User-Id": "student-03"})
    assert denied.status_code == 403


def test_teacher_knowledge_graph_accepts_docx_and_pdf(client):
    document_buffer = BytesIO()
    document = Document()
    document.add_heading("动态规划方法", level=1)
    document.add_paragraph("状态转移公式、递推步骤、综合案例实践和算法能力目标。")
    document.save(document_buffer)

    pdf_buffer = BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=300, height=300)
    writer.write(pdf_buffer)

    response = client.post(
        "/api/teacher/knowledge-graphs/from-files",
        data={"title": "Word PDF 格式验收"},
        files=[
            ("files", ("lesson.docx", document_buffer.getvalue(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
            ("files", ("appendix.pdf", pdf_buffer.getvalue(), "application/pdf")),
        ],
    )
    assert response.status_code == 201, response.text
    graph = response.json()["data"]
    assert [item["filename"] for item in graph["source_files"]] == ["lesson.docx", "appendix.pdf"]
    assert graph["node_count"] >= 6
    assert client.delete(f"/api/teacher/knowledge-graphs/{graph['id']}").status_code == 200


def test_teacher_knowledge_graph_reuses_rag_parser_for_markdown_and_pptx(client):
    deck_buffer = BytesIO()
    deck = Presentation()
    slide = deck.slides.add_slide(deck.slide_layouts[1])
    slide.shapes.title.text = "监督学习"
    slide.placeholders[1].text = "损失函数\n梯度下降\n模型评估"
    deck.save(deck_buffer)

    response = client.post(
        "/api/teacher/knowledge-graphs/from-files",
        data={"title": "机器学习资料图谱"},
        files=[
            ("files", ("lesson.markdown", "# 机器学习\n## 过拟合\n正则化方法".encode("utf-8"), "text/markdown")),
            ("files", ("slides.pptx", deck_buffer.getvalue(), "application/vnd.openxmlformats-officedocument.presentationml.presentation")),
        ],
    )
    assert response.status_code == 201, response.text
    graph = response.json()["data"]
    assert [item["filename"] for item in graph["source_files"]] == ["lesson.markdown", "slides.pptx"]
    assert {item["parser"] for item in graph["source_files"]} == {"markdown", "python-pptx"}
    assert any(item["content_profile"] == "slide_deck" for item in graph["source_files"])
    assert graph["node_count"] >= 6
    assert "父切片" in graph["source_summary"]
    assert client.delete(f"/api/teacher/knowledge-graphs/{graph['id']}").status_code == 200


def test_teacher_knowledge_graph_node_attachments_are_stored_in_table(client):
    created = client.post(
        "/api/teacher/knowledge-graphs",
        json={"title": "节点挂载知识图谱", "nodes": [{"id": "node-attachment-test", "label": "梯度下降", "type": "方法"}]},
    )
    assert created.status_code == 201, created.text
    graph = created.json()["data"]

    attachment = client.post(
        f"/api/teacher/knowledge-graphs/{graph['id']}/nodes/node-attachment-test/attachments",
        json={
            "title": "课前补充阅读",
            "resource_type": "text",
            "content": "先理解损失函数，再看参数沿负梯度方向更新。",
            "link_url": "",
        },
    )
    assert attachment.status_code == 201, attachment.text
    attachment_id = attachment.json()["data"]["id"]

    file_attachment = client.post(
        f"/api/teacher/knowledge-graphs/{graph['id']}/nodes/node-attachment-test/attachments/file",
        data={"title": "节点讲义文件"},
        files={"file": ("gradient.md", b"# Gradient\nextra material", "text/markdown")},
    )
    assert file_attachment.status_code == 201, file_attachment.text
    file_data = file_attachment.json()["data"]
    assert file_data["resource_type"] == "file"
    assert file_data["file_name"] == "gradient.md"
    assert file_data["file_size_bytes"] == len(b"# Gradient\nextra material")

    with SessionLocal() as db:
        stored = db.get(TeacherGraphNodeAttachment, attachment_id)
        assert stored is not None
        assert stored.node_id == "node-attachment-test"
        stored_file = db.get(TeacherGraphNodeAttachment, file_data["id"])
        assert stored_file is not None
        assert stored_file.resource_type == "file"
        assert stored_file.stored_name

    detail = client.get(f"/api/teacher/knowledge-graphs/{graph['id']}").json()["data"]
    node = next(item for item in detail["nodes"] if item["id"] == "node-attachment-test")
    assert node["attachments"][0]["title"] == "课前补充阅读"
    assert {item["resource_type"] for item in node["attachments"]} == {"text", "file"}

    file_response = client.get(file_data["file_url"], headers={"X-User-Id": "teacher-01"})
    assert file_response.status_code == 200
    assert file_response.content == b"# Gradient\nextra material"
    assert client.get(file_data["file_url"]).status_code == 404

    published = client.post(f"/api/teacher/knowledge-graphs/{graph['id']}/publish", json={"class_ids": ["class-se1"]})
    assert published.status_code == 200
    public_file_response = client.get(file_data["file_url"])
    assert public_file_response.status_code == 200
    assert public_file_response.content == b"# Gradient\nextra material"

    deleted = client.delete(
        f"/api/teacher/knowledge-graphs/{graph['id']}/nodes/node-attachment-test/attachments/{attachment_id}"
    )
    assert deleted.status_code == 200
    detail_after_delete = client.get(f"/api/teacher/knowledge-graphs/{graph['id']}").json()["data"]
    node_after_delete = next(item for item in detail_after_delete["nodes"] if item["id"] == "node-attachment-test")
    assert [item["resource_type"] for item in node_after_delete["attachments"]] == ["file"]

    second = client.post(
        f"/api/teacher/knowledge-graphs/{graph['id']}/nodes/node-attachment-test/attachments",
        json={
            "title": "外部资料",
            "resource_type": "link",
            "content": "",
            "link_url": "https://example.com/gradient-descent",
        },
    ).json()["data"]
    saved = client.put(
        f"/api/teacher/knowledge-graphs/{graph['id']}",
        json={
            "title": "节点挂载知识图谱",
            "description": "",
            "target_classes": [],
            "status": "draft",
            "nodes": [],
            "edges": [],
        },
    )
    assert saved.status_code == 200
    with SessionLocal() as db:
        assert db.get(TeacherGraphNodeAttachment, second["id"]) is None
        assert db.get(TeacherGraphNodeAttachment, file_data["id"]) is None

    assert client.delete(f"/api/teacher/knowledge-graphs/{graph['id']}").status_code == 200



