# CodeTrack 人工智能学科垂直大模型微调数据集构建说明

## 1. 数据建设目标

构建面向人工智能专业教学场景的垂直大模型，覆盖：

- Python程序设计
- 数据结构
- 机器学习

目标：
- 学习专业知识
- 学习教学式回答方式
- 学生问题诊断
- 个性化学习指导


## 2. 数据体系划分

```
数据体系

├── SFT微调数据
└── RAG知识库数据
```

## 2.1 SFT微调数据

作用：

训练模型“如何回答问题”。

特点：

- 问题 + 标准答案
- 教学风格
- 错误诊断
- 分层指导


格式：

```json
{
  "messages":[
    {
      "role":"system",
      "content":"你是人工智能专业教学助手"
    },
    {
      "role":"user",
      "content":"学生问题"
    },
    {
      "role":"assistant",
      "content":"标准教学回答"
    }
  ],
  "course":"machine_learning"
}
```


## 2.2 RAG知识库数据

作用：

提供课程知识，不参与模型参数训练。

流程：

```
教材/PPT/文档
↓
文本切分
↓
向量化
↓
知识库
↓
检索增强回答
```


# 3. 数据来源

## Python

主要来源：

- CS1QA（Python课程真实问答）
- Python官方文档
- 课程教材/PPT

覆盖：

- Python基础
- 函数
- 类
- 代码错误分析


## 数据结构

主要来源：

- OpenDSA
- Open Data Structures
- 课程资料

覆盖：

- 链表
- 栈
- 队列
- 树
- 图
- 排序
- 查找
- 时间复杂度


## 机器学习

主要来源：

- scikit-learn官方文档
- MIT Machine Learning课程
- 课程教材/PPT

覆盖：

- 监督学习
- 线性回归
- 逻辑回归
- 决策树
- SVM
- KNN
- 聚类
- 过拟合
- 模型评估


# 4. SFT数据构建流程

```
数据采集
↓
格式统一
↓
数据清洗
↓
问题答案构造
↓
质量检查
↓
JSONL训练文件
```


# 5. SFT数据类型

## 概念解释

训练模型解释专业知识。

例如：

问题：
什么是梯度下降？

回答：
梯度下降是一种优化算法……


## 代码分析

训练模型理解代码。

例如：

学生代码：

```python
for i in range(len(a)+1):
    print(a[i])
```

回答：

分析数组越界原因。


## 错误诊断

例如：

学生：

训练准确率99%，测试准确率70%，为什么？

回答：

分析过拟合、数据划分、模型复杂度。


## 引导式教学

目标：

不要直接给答案，而是引导学生思考。


# 6. 数据清洗规则

删除：

- 空问题
- 空答案
- 无关内容
- 重复样本
- 低质量回答

处理：

- 文本规范化
- 去HTML
- 去噪
- 去重


# 7. 最终训练产物

## SFT

```
train.jsonl

validation.jsonl
```


## RAG

```
python.jsonl

data_structure.jsonl

machine_learning.jsonl
```


# 8. 推荐规模

针对：

- Qwen3-1.7B
- QLoRA
- 免费GPU


SFT：

```
总量：5000-6000条

Python：2000条左右

数据结构：1500条左右

机器学习：1500条左右

教学行为：500条左右
```


RAG：

```
3000-5000知识块
```


# 9. 最终目录结构

```
CodeTrack-Dataset

├── SFT
│   ├── train.jsonl
│   ├── validation.jsonl
│   ├── python
│   ├── data_structure
│   └── machine_learning
│
└── RAG
    ├── python
    ├── data_structure
    └── machine_learning
```


# 10. 核心原则

SFT：

> 学习模型能力、教学方式和回答风格。


RAG：

> 提供课程知识和外部资料。


不要：

```
教材全文直接训练
```


正确方式：

```
教材
↓
RAG知识库

教材加工
↓
SFT训练样本
```


最终形成：

```
课程知识
+
教学能力
+
学生理解能力

=

人工智能学科垂直大模型
```
