"""Core backend utilities."""

